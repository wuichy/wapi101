<?php
/**
 * Plugin Name:  Reelance Conexión Wapi101
 * Plugin URI:   https://wapi101.com
 * Description:  Sincroniza pedidos de WooCommerce con Wapi101 CRM automáticamente.
 * Version:      2.2.0
 * Author:       Wapi101
 * Author URI:   https://wapi101.com
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'RWAPI_VERSION', '2.5.0' );
define( 'RWAPI_OPTION',  'rwapi101_settings' );

// ── Activación / Desactivación ───────────────────────────────────────────────
register_activation_hook( __FILE__,   '__rwapi_activate' );
register_deactivation_hook( __FILE__, '__rwapi_deactivate' );
function __rwapi_activate()   { add_option( RWAPI_OPTION, [] ); }
function __rwapi_deactivate() { /* no-op */ }

// ── Admin menu ───────────────────────────────────────────────────────────────
add_action( 'admin_menu', 'rwapi_admin_menu' );
function rwapi_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Reelance Wapi101',
        'Reelance Wapi101',
        'manage_options',
        'rwapi101',
        'rwapi_settings_page'
    );
}

// ── Guardar settings ─────────────────────────────────────────────────────────
add_action( 'admin_init', 'rwapi_register_settings' );
function rwapi_register_settings() {
    register_setting( 'rwapi101_group', RWAPI_OPTION, 'rwapi_sanitize' );
}
function rwapi_sanitize( $input ) {
    return [
        'webhook_url' => esc_url_raw( trim( $input['webhook_url'] ?? '' ) ),
        'token'       => sanitize_text_field( trim( $input['token'] ?? '' ) ),
        'enabled'     => ! empty( $input['enabled'] ) ? 1 : 0,
    ];
}

// ── Página de configuración ──────────────────────────────────────────────────
function rwapi_settings_page() {
    $opts    = get_option( RWAPI_OPTION, [] );
    $url     = $opts['webhook_url'] ?? '';
    $token   = $opts['token']       ?? '';
    $enabled = $opts['enabled']     ?? 0;
    ?>
    <div class="wrap">
        <h1>🛒 Reelance Conexión Wapi101 <small style="font-size:13px;color:#666">v<?php echo RWAPI_VERSION; ?></small></h1>

        <?php if ( $url && $token ): ?>
        <div style="margin-bottom:20px;padding:14px 18px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;display:flex;align-items:center;gap:12px">
            <span style="font-size:24px;line-height:1">✅</span>
            <div>
                <strong style="color:#15803d;font-size:14px">Vinculado con Wapi101</strong>
                <p style="margin:3px 0 0;font-size:12px;color:#166534">Este plugin está configurado y enviando eventos de pedidos a Wapi101 CRM.</p>
            </div>
        </div>
        <?php else: ?>
        <div style="margin-bottom:20px;padding:14px 18px;background:#fffbeb;border:1px solid #fcd34d;border-radius:8px;display:flex;align-items:center;gap:12px">
            <span style="font-size:24px;line-height:1">⚠️</span>
            <div>
                <strong style="color:#92400e;font-size:14px">Sin vincular</strong>
                <p style="margin:3px 0 0;font-size:12px;color:#78350f">Configura la URL del webhook y el token para vincular con Wapi101 CRM.</p>
            </div>
        </div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php settings_fields('rwapi101_group'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="rwapi_url">URL del Webhook</label></th>
                    <td>
                        <input type="url" id="rwapi_url" name="<?php echo RWAPI_OPTION; ?>[webhook_url]"
                               value="<?php echo esc_attr($url); ?>" class="regular-text"
                               placeholder="https://wapi101.com/webhooks/woo" />
                        <p class="description">Copia la URL que aparece en la app Reelance WooCommerce dentro de Wapi101.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="rwapi_token">Token de conexión</label></th>
                    <td>
                        <input type="text" id="rwapi_token" name="<?php echo RWAPI_OPTION; ?>[token]"
                               value="<?php echo esc_attr($token); ?>" class="regular-text"
                               placeholder="woo_xxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">Copia el token que aparece en la pestaña Conexión de la app en Wapi101.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="rwapi_enabled">Activar sincronización</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="rwapi_enabled" name="<?php echo RWAPI_OPTION; ?>[enabled]"
                                   value="1" <?php checked(1, $enabled); ?> />
                            Enviar eventos a Wapi101 cuando cambien los pedidos
                        </label>
                    </td>
                </tr>
            </table>
            <?php submit_button('Guardar configuración'); ?>
        </form>
        <?php if ($token): ?>
        <div style="margin-top:16px;padding:14px 16px;background:#f0f6ff;border:1px solid #c7d9f5;border-radius:6px;">
            <strong>Tu token de Wapi101:</strong>
            <code style="display:block;margin:8px 0;padding:8px 12px;background:#fff;border:1px solid #ddd;border-radius:4px;font-size:13px;word-break:break-all;"><?php echo esc_html($token); ?></code>
            <p style="margin:0;font-size:12px;color:#555;">Copia este token y pégalo en <strong>Wapi101 → Apps → WooCommerce → Pestaña Conexión</strong>.</p>
        </div>
        <?php endif; ?>
        <?php if ($url && $token): ?>
        <hr>
        <h3>🧪 Probar conexión</h3>
        <form method="post">
            <?php wp_nonce_field('rwapi_test', 'rwapi_nonce'); ?>
            <input type="hidden" name="rwapi_action" value="test" />
            <?php submit_button('Enviar evento de prueba', 'secondary'); ?>
        </form>
        <?php if (isset($_POST['rwapi_action']) && $_POST['rwapi_action'] === 'test'
               && check_admin_referer('rwapi_test', 'rwapi_nonce')): ?>
            <?php
            $result = rwapi_send_event('order.test', ['message' => 'Prueba de conexión desde WordPress']);
            if (is_wp_error($result)) {
                echo '<div class="notice notice-error"><p>Error: ' . esc_html($result->get_error_message()) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>✅ Conexión exitosa con Wapi101.</p></div>';
            }
            ?>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}

// ── Hook: cambio de status de pedido ─────────────────────────────────────────
add_action( 'woocommerce_order_status_changed', 'rwapi_on_order_status_changed', 10, 4 );
function rwapi_on_order_status_changed( $order_id, $old_status, $new_status, $order ) {
    $opts    = get_option( RWAPI_OPTION, [] );
    $enabled = $opts['enabled'] ?? 0;
    if ( ! $enabled ) return;

    // Enviar evento para cualquier cambio de estatus — el servidor filtra según trigger_statuses
    rwapi_send_order_event( 'order.' . $new_status, $order );
}

// ── Hook adicional: pedidos creados directamente con estatus inicial (ej. Oxxo → on-hold) ──
add_action( 'woocommerce_new_order', 'rwapi_on_new_order', 10, 2 );
function rwapi_on_new_order( $order_id, $order ) {
    $opts    = get_option( RWAPI_OPTION, [] );
    $enabled = $opts['enabled'] ?? 0;
    if ( ! $enabled ) return;

    $status = $order->get_status();
    // Evitar duplicado si el status_changed ya lo manejó
    if ( $status === 'pending' ) return; // pending siempre dispara status_changed después
    rwapi_send_order_event( 'order.' . $status, $order );
}

// ── Cron: carritos abandonados de CartBounty Pro ─────────────────────────────
// Cada 5 minutos consulta wp_cartbounty_pro y manda a Wapi101 los carritos
// que cumplan: tiene phone, no convertido a pedido, mínimo X min desde
// abandono, no enviado en las últimas Y horas, no excluido del webhook.
// Usamos wh_last_synced (columna nativa de CartBounty para webhooks) como
// flag de dedup persistente.

if ( ! wp_next_scheduled( 'rwapi_cartbounty_sync' ) ) {
    wp_schedule_event( time() + 60, 'rwapi_5min', 'rwapi_cartbounty_sync' );
}
add_filter( 'cron_schedules', function( $s ) {
    $s['rwapi_5min'] = [ 'interval' => 300, 'display' => 'Cada 5 minutos (Wapi101)' ];
    return $s;
} );
add_action( 'rwapi_cartbounty_sync', 'rwapi_sync_abandoned_carts' );

function rwapi_sync_abandoned_carts() {
    global $wpdb;
    $opts    = get_option( RWAPI_OPTION, [] );
    $enabled = $opts['enabled'] ?? 0;
    if ( ! $enabled ) return;

    $table = $wpdb->prefix . 'cartbounty_pro';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) return;

    // Mínimo 30 min de abandono (CartBounty corre su propia lógica de timing;
    // este es solo un buffer mínimo para no agarrar carts en sesión activa).
    $min_minutes = 30;
    $dedup_hours = 24;

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, name, surname, email, phone, cart_contents, cart_total, currency, time, session_id, type, wc_order_id
         FROM $table
         WHERE phone IS NOT NULL AND phone != ''
           AND ( wc_order_id IS NULL OR wc_order_id = 0 )
           AND TIMESTAMPDIFF(MINUTE, time, NOW()) >= %d
           AND ( wh_last_synced IS NULL OR wh_last_synced = '0000-00-00 00:00:00' OR wh_last_synced < (NOW() - INTERVAL %d HOUR) )
           AND COALESCE(wh_excluded, 0) = 0
         ORDER BY time DESC LIMIT 20",
        $min_minutes, $dedup_hours
    ) );

    if ( empty( $rows ) ) return;

    foreach ( $rows as $row ) {
        $products = [];
        if ( ! empty( $row->cart_contents ) ) {
            $items = @maybe_unserialize( $row->cart_contents );
            if ( is_array( $items ) ) {
                foreach ( $items as $it ) {
                    $pid  = isset( $it['product_id'] ) ? (int) $it['product_id'] : 0;
                    $qty  = isset( $it['quantity'] )   ? (int) $it['quantity']   : 1;
                    $name = '';
                    if ( $pid ) {
                        $p = wc_get_product( $pid );
                        if ( $p ) $name = $p->get_name();
                    }
                    if ( ! $name && isset( $it['product_name'] ) ) $name = $it['product_name'];
                    $products[] = [ 'product_id' => $pid, 'name' => $name, 'quantity' => $qty ];
                }
            }
        }

        // Link de recuperación: usa la URL del checkout con session_id como parámetro.
        // CartBounty Pro tiene su propio sistema de tokens — si no lo tenemos, usamos
        // simplemente la URL del checkout (mejor que nada).
        $cart_url = wc_get_checkout_url();
        if ( ! empty( $row->session_id ) ) {
            $cart_url = add_query_arg( 'cb_recover', $row->session_id, $cart_url );
        }

        $payload = [
            'event' => 'cart.abandoned',
            'cart'  => [
                'cb_cart_id' => (int) $row->id,
                'name'       => $row->name,
                'surname'    => $row->surname,
                'email'      => $row->email,
                'phone'      => $row->phone,
                'products'   => $products,
                'total'      => $row->cart_total ? (float) $row->cart_total : 0,
                'currency'   => $row->currency ?: 'MXN',
                'cart_url'   => $cart_url,
                'time'       => $row->time,
            ],
        ];

        $result = rwapi_send_event( 'cart.abandoned', $payload );
        if ( ! is_wp_error( $result ) ) {
            // Marcar como sincronizado para deduplicación
            $wpdb->update(
                $table,
                [ 'wh_last_synced' => current_time( 'mysql', true ) ],
                [ 'id' => $row->id ],
                [ '%s' ], [ '%d' ]
            );
        }
    }
}

// Limpieza al desactivar
register_deactivation_hook( __FILE__, function() {
    wp_clear_scheduled_hook( 'rwapi_cartbounty_sync' );
} );

// ── Hooks: borrar / mandar a papelera ────────────────────────────────────────
// HPOS (WC ≥ 7.1): woocommerce_delete_order / woocommerce_trash_order
add_action( 'woocommerce_delete_order', 'rwapi_on_order_delete', 10, 1 );
add_action( 'woocommerce_trash_order',  'rwapi_on_order_delete', 10, 1 );
// Tablas clásicas (fallback): before_delete_post / wp_trash_post
add_action( 'before_delete_post', 'rwapi_on_post_delete', 10, 1 );
add_action( 'wp_trash_post',      'rwapi_on_post_delete', 10, 1 );

function rwapi_on_order_delete( $order_id ) {
    $opts    = get_option( RWAPI_OPTION, [] );
    $enabled = $opts['enabled'] ?? 0;
    if ( ! $enabled ) return;
    rwapi_send_delete_event( (int) $order_id );
}

function rwapi_on_post_delete( $post_id ) {
    if ( get_post_type( $post_id ) !== 'shop_order' ) return;
    $opts    = get_option( RWAPI_OPTION, [] );
    $enabled = $opts['enabled'] ?? 0;
    if ( ! $enabled ) return;
    rwapi_send_delete_event( (int) $post_id );
}

function rwapi_send_delete_event( $order_id ) {
    $payload = [
        'event' => 'order.deleted',
        'order' => [ 'id' => $order_id ],
    ];
    rwapi_send_event( 'order.deleted', $payload );
}

// ── Construir y enviar payload ────────────────────────────────────────────────
function rwapi_send_order_event( $event, $order ) {
    $billing = [
        'first_name' => $order->get_billing_first_name(),
        'last_name'  => $order->get_billing_last_name(),
        'phone'      => $order->get_billing_phone(),
        'email'      => $order->get_billing_email(),
    ];

    // Productos
    $line_items = [];
    foreach ( $order->get_items() as $item ) {
        $line_items[] = [
            'product_id' => $item->get_product_id(),
            'name'       => $item->get_name(),
            'quantity'   => $item->get_quantity(),
        ];
    }

    // Tracking — WooCommerce Orders Tracking Premium (VillaTheme) usa prefijo _wot_
    $tracking = [];
    $t_carrier = $order->get_meta( '_wot_tracking_carrier' );
    $t_number  = $order->get_meta( '_wot_tracking_number' );

    // Fallback: WooCommerce Shipment Tracking (SkyVerge/free) — _wc_shipment_tracking_items
    if ( ! $t_carrier && ! $t_number ) {
        $tracking_items = $order->get_meta( '_wc_shipment_tracking_items' );
        if ( ! $tracking_items ) $tracking_items = $order->get_meta( 'wc_order_tracking_items' );
        if ( is_array( $tracking_items ) && ! empty( $tracking_items ) ) {
            $t         = $tracking_items[0];
            $t_carrier = $t['formatted_tracking_provider'] ?? $t['tracking_provider'] ?? $t['carrier'] ?? '';
            $t_number  = $t['tracking_number'] ?? '';
        }
    }

    // Fallback: meta keys genéricas
    if ( ! $t_carrier ) {
        $t_carrier = $order->get_meta('_order_tracking_carrier') ?: $order->get_meta('_shipping_provider') ?: '';
        $t_number  = $order->get_meta('_order_tracking_number') ?: $order->get_meta('_tracking_number') ?: '';
    }

    $tracking = [
        'carrier'         => $t_carrier ?: '',
        'tracking_number' => $t_number  ?: '',
    ];

    $shipping = [
        'first_name' => $order->get_shipping_first_name(),
        'last_name'  => $order->get_shipping_last_name(),
        'address_1'  => $order->get_shipping_address_1(),
        'address_2'  => $order->get_shipping_address_2(),
        'city'       => $order->get_shipping_city(),
        'state'      => $order->get_shipping_state(),
        'postcode'   => $order->get_shipping_postcode(),
        'country'    => $order->get_shipping_country(),
    ];

    $payload = [
        'event' => $event,
        'order' => [
            'id'                   => $order->get_id(),
            'number'               => $order->get_order_number(),
            'status'               => $order->get_status(),
            'date_created'         => $order->get_date_created()?->format('c'),
            'total'                => (string) $order->get_total(),
            'shipping_total'       => (string) $order->get_shipping_total(),
            'discount_total'       => (string) $order->get_discount_total(),
            'total_tax'            => (string) $order->get_total_tax(),
            'payment_method'       => $order->get_payment_method(),
            'payment_method_title' => $order->get_payment_method_title(),
            'customer_note'        => $order->get_customer_note(),
            'billing'              => $billing,
            'shipping'             => $shipping,
            'line_items'           => $line_items,
            'shipping_tracking'    => $tracking,
        ],
    ];

    rwapi_send_event( $event, $payload );
}

function rwapi_send_event( $event, $payload ) {
    $opts  = get_option( RWAPI_OPTION, [] );
    $url   = $opts['webhook_url'] ?? '';
    $token = $opts['token']       ?? '';
    if ( ! $url || ! $token ) return new WP_Error('rwapi_no_config', 'URL o token no configurado');

    $response = wp_remote_post( $url, [
        'headers'     => [
            'Content-Type' => 'application/json',
            'X-Wapi-Token' => $token,
        ],
        'body'        => wp_json_encode( $payload ),
        'timeout'     => 15,
        'data_format' => 'body',
    ] );

    if ( is_wp_error( $response ) ) {
        error_log( '[Reelance Wapi101] Error: ' . $response->get_error_message() );
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code >= 400 ) {
        $body = wp_remote_retrieve_body( $response );
        error_log( "[Reelance Wapi101] HTTP {$code}: {$body}" );
        return new WP_Error( 'rwapi_http_error', "HTTP {$code}" );
    }

    return true;
}

// ── REST API endpoints ───────────────────────────────────────────────────────
add_action( 'rest_api_init', 'rwapi_register_rest_routes' );
function rwapi_register_rest_routes() {
    register_rest_route( 'wapi101/v1', '/carriers', [
        'methods'             => 'GET',
        'callback'            => 'rwapi_rest_get_carriers',
        'permission_callback' => 'rwapi_rest_check_token',
    ]);
    register_rest_route( 'wapi101/v1', '/orders/(?P<id>\d+)/tracking', [
        'methods'             => 'PUT',
        'callback'            => 'rwapi_rest_update_tracking',
        'permission_callback' => 'rwapi_rest_check_token',
        'args'                => [
            'id' => [ 'validate_callback' => function( $p ) { return is_numeric( $p ); } ],
        ],
    ]);
}

function rwapi_rest_check_token( $request ) {
    $opts  = get_option( RWAPI_OPTION, [] );
    $token = $opts['token'] ?? '';
    if ( ! $token ) return new WP_Error( 'rwapi_no_token', 'Token no configurado', [ 'status' => 401 ] );
    $req_token = $request->get_header('X-Wapi-Token');
    if ( $req_token !== $token ) return new WP_Error( 'rwapi_invalid_token', 'Token inválido', [ 'status' => 401 ] );
    return true;
}

function rwapi_rest_get_carriers( $request ) {
    $carriers = [];

    // ── WooCommerce Orders Tracking Premium by VillaTheme ────────────────────
    // Clase: VI_WOOCOMMERCE_ORDERS_TRACKING_DATA
    // Option: woo_orders_tracking_settings → active_carriers (array de slugs)
    if ( class_exists( 'VI_WOOCOMMERCE_ORDERS_TRACKING_DATA' ) ) {
        try {
            $settings     = get_option( 'woo_orders_tracking_settings', [] );
            $active_slugs = isset( $settings['active_carriers'] ) ? (array) $settings['active_carriers'] : [];

            // Paqueterías predefinidas — filtrar solo las activas
            if ( method_exists( 'VI_WOOCOMMERCE_ORDERS_TRACKING_DATA', 'get_carriers' ) ) {
                $all = VI_WOOCOMMERCE_ORDERS_TRACKING_DATA::get_carriers();
                foreach ( (array) $all as $c ) {
                    if ( in_array( $c['slug'] ?? '', $active_slugs, true ) ) {
                        $carriers[] = [ 'id' => $c['slug'], 'name' => $c['name'] ];
                    }
                }
            }

            // Paqueterías personalizadas (siempre se muestran)
            if ( method_exists( 'VI_WOOCOMMERCE_ORDERS_TRACKING_DATA', 'get_custom_carriers' ) ) {
                foreach ( (array) VI_WOOCOMMERCE_ORDERS_TRACKING_DATA::get_custom_carriers() as $c ) {
                    $slug = $c['slug'] ?? sanitize_title( $c['name'] ?? '' );
                    $name = ! empty( $c['display_name'] ) ? $c['display_name'] : ( $c['name'] ?? $slug );
                    if ( $slug && $name ) {
                        $carriers[] = [ 'id' => $slug, 'name' => $name ];
                    }
                }
            }
        } catch ( \Throwable $e ) {
            $carriers = [];
        }
    }

    // ── Legacy: WooCommerce Shipment Tracking (SkyVerge/free) ────────────────
    if ( empty( $carriers ) && class_exists( 'WC_Shipment_Tracking_Actions' ) ) {
        $st = WC_Shipment_Tracking_Actions::get_instance();
        foreach ( $st->get_providers() as $country => $list ) {
            foreach ( $list as $name => $url ) {
                $carriers[] = [ 'id' => sanitize_title( $name ), 'name' => $name ];
            }
        }
    }

    // ── Fallback: carriers comunes MX ─────────────────────────────────────────
    if ( empty( $carriers ) ) {
        $carriers = [
            [ 'id' => 'estafeta',      'name' => 'Estafeta' ],
            [ 'id' => 'fedex',         'name' => 'FedEx' ],
            [ 'id' => 'dhl',           'name' => 'DHL' ],
            [ 'id' => 'ups',           'name' => 'UPS' ],
            [ 'id' => 'redpack',       'name' => 'Redpack' ],
            [ 'id' => 'paquetexpress', 'name' => 'Paquete Express' ],
            [ 'id' => 'ampm',          'name' => 'AM/PM' ],
            [ 'id' => 'jtexpress',     'name' => 'J&T Express' ],
            [ 'id' => 'tresguerras',   'name' => 'Tres Guerras' ],
        ];
    }

    return rest_ensure_response( [ 'carriers' => $carriers ] );
}

function rwapi_rest_update_tracking( $request ) {
    $order_id        = absint( $request['id'] );
    $carrier         = sanitize_text_field( $request->get_param('carrier') );
    $tracking_number = sanitize_text_field( $request->get_param('tracking_number') );
    $tracking_status = sanitize_text_field( $request->get_param('tracking_status') );

    $order = wc_get_order( $order_id );
    if ( ! $order ) return new WP_Error( 'not_found', 'Orden no encontrada', [ 'status' => 404 ] );

    // Guardar en formato VillaTheme WooCommerce Orders Tracking Premium (_wot_ prefix)
    $order->update_meta_data( '_wot_tracking_number', $tracking_number );
    $order->update_meta_data( '_wot_tracking_carrier', $carrier );
    $order->update_meta_data( '_wot_tracking_status',  $tracking_status );

    // Meta auxiliar para compatibilidad
    $order->update_meta_data( '_wapi101_tracking_status', $tracking_status );

    // Si status es 'entregado' completar orden
    if ( $tracking_status === 'entregado' && $order->get_status() !== 'completed' ) {
        $order->update_status( 'completed', 'Entregado via Wapi101.' );
    } elseif ( $tracking_status === 'en_camino' && in_array( $order->get_status(), [ 'processing', 'on-hold' ], true ) ) {
        $order->add_order_note( "Paquete en camino. Paquetería: {$carrier}. Rastreo: {$tracking_number}. Actualizado desde Wapi101." );
    }

    $order->save();
    return rest_ensure_response( [ 'ok' => true ] );
}
